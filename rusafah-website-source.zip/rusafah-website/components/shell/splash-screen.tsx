import { RusafahLogo } from "@/components/patterns/rusafah-logo";

/**
 * First-paint splash from the design's "loading interface" artboard. Pure CSS:
 * it fades itself out after the page has painted and never blocks interaction
 * for more than ~1.5s. Respects prefers-reduced-motion (the animation collapses,
 * so the overlay disappears immediately).
 */
export function SplashScreen() {
  return (
    <div
      aria-hidden="true"
      className="splash-exit bg-navy-900 pointer-events-none fixed inset-0 z-[100] flex items-center justify-center"
    >
      <RusafahLogo className="text-cream-200 h-14 w-auto" />
    </div>
  );
}
