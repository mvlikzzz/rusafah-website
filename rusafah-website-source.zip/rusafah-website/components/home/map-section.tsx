"use client";

import * as React from "react";
import Image from "next/image";
import Link from "next/link";
import { ChevronLeft, ChevronRight, Search } from "lucide-react";
import { ProjectsMap, type MapPin } from "@/components/map/projects-map";
import { Button } from "@/components/ui/button";
import { COPY } from "@/lib/copy";
import { cn } from "@/lib/utils";
import { PROPERTY_TYPES, propertyTypeLabel } from "@/modules/projects/vocabulary";

type Props = {
  pins: MapPin[];
  districts: { city: string; district: string }[];
};

/** "خارطة رُصافة": filter bar (a GET form to /projects), the map, and the active-project card. */
export function MapSection({ pins, districts }: Props) {
  const [active, setActive] = React.useState<string | null>(pins[0]?.slug ?? null);
  const [listing, setListing] = React.useState<"sale" | "rent">("sale");
  const current = pins.find((p) => p.slug === active) ?? null;
  const idx = current ? pins.indexOf(current) : -1;
  const step = (d: number) => {
    if (!pins.length) return;
    setActive(pins[(idx + d + pins.length) % pins.length]!.slug);
  };

  return (
    <div>
      <div className="mb-6 flex items-center justify-between gap-4">
        <h2 className="text-gold-600 flex items-center gap-3 text-3xl font-medium md:text-4xl">
          <span aria-hidden="true" className="diamond text-navy-900" />
          {COPY.home.mapTitle}
        </h2>
        <Link href="/projects" className="text-gold-700 text-xl underline-offset-4 hover:underline">
          {COPY.home.viewAllProjects}
        </Link>
      </div>

      <div className="relative">
        <ProjectsMap
          pins={pins}
          activeSlug={active}
          onActiveChange={setActive}
          className="h-[42rem] md:h-[46rem]"
        />

        {/* Filter bar */}
        <form
          action="/projects"
          method="get"
          className="absolute inset-x-4 top-4 z-10 flex flex-col gap-3 md:inset-x-8 md:top-6 md:flex-row md:items-center"
          aria-label="بحث في المشاريع"
        >
          <button
            type="submit"
            className="bg-navy-900 text-cream-100 hidden size-16 items-center justify-center rounded-full md:flex"
            aria-label="عرض النتائج"
          >
            <Search className="size-7" aria-hidden="true" />
          </button>
          <div className="border-cream-200/60 bg-cream-200/25 flex flex-1 flex-wrap items-center gap-3 rounded-md border p-3 backdrop-blur-md">
            <label className="sr-only" htmlFor="map-type">
              نوع العقار
            </label>
            <select
              id="map-type"
              name="types"
              className="select-brand bg-cream-200 text-navy-900 min-w-44 flex-1 rounded-xs py-3"
            >
              <option value="">نوع العقــــار</option>
              {PROPERTY_TYPES.map((t) => (
                <option key={t} value={t}>
                  {propertyTypeLabel(t)}
                </option>
              ))}
            </select>
            <label className="sr-only" htmlFor="map-district">
              المنطقة
            </label>
            <select
              id="map-district"
              name="district"
              className="select-brand bg-cream-200 text-navy-900 min-w-44 flex-1 rounded-xs py-3"
            >
              <option value="">المنطقـة</option>
              {districts.map((d) => (
                <option key={`${d.city}-${d.district}`} value={d.district}>
                  {d.city} - {d.district}
                </option>
              ))}
            </select>
            <label className="sr-only" htmlFor="map-q">
              البحث حسب الاسم
            </label>
            <input
              id="map-q"
              name="q"
              placeholder="البحث حسب"
              className="bg-cream-200 text-navy-900 placeholder:text-gold-700/80 min-w-40 flex-1 rounded-xs px-4 py-3"
            />
            <Button type="submit" variant="gold" className="rounded-xs py-3">
              عرض
            </Button>
          </div>
          <div
            className="bg-navy-900 text-cream-100 flex overflow-hidden rounded-md"
            role="group"
            aria-label="نوع العرض"
          >
            {(["sale", "rent"] as const).map((v) => (
              <button
                key={v}
                type="button"
                aria-pressed={listing === v}
                onClick={() => setListing(v)}
                className={cn(
                  "px-6 py-3 text-lg",
                  listing === v ? "text-gold-400" : "opacity-75 hover:opacity-100",
                )}
              >
                {v === "sale" ? "بيــع" : "ايجار"}
              </button>
            ))}
            <input type="hidden" name="listing" value={listing} />
          </div>
        </form>

        {/* Active project card */}
        {current ? (
          <aside
            className="bg-navy-900 text-cream-100 shadow-glow absolute start-4 bottom-4 z-10 w-56 overflow-hidden rounded-md md:start-8 md:bottom-8 md:w-80"
            aria-live="polite"
          >
            <div className="relative aspect-[3/4]">
              {current.image ? (
                <Image src={current.image} alt="" fill sizes="20rem" className="object-cover" />
              ) : null}
              <div
                aria-hidden="true"
                className="from-navy-950/90 via-navy-950/20 absolute inset-0 bg-gradient-to-t to-transparent"
              />
              <div className="absolute start-3 top-3 flex gap-1">
                <button
                  type="button"
                  onClick={() => step(1)}
                  aria-label="المشروع التالي"
                  className="bg-cream-100/15 hover:bg-cream-100/30 rounded-full p-1.5"
                >
                  <ChevronRight className="size-5" aria-hidden="true" />
                </button>
                <button
                  type="button"
                  onClick={() => step(-1)}
                  aria-label="المشروع السابق"
                  className="bg-cream-100/15 hover:bg-cream-100/30 rounded-full p-1.5"
                >
                  <ChevronLeft className="size-5" aria-hidden="true" />
                </button>
              </div>
              <div className="absolute inset-x-0 bottom-0 p-5">
                <p className="flex items-center gap-2 text-lg">
                  <span aria-hidden="true" className="bg-status-available size-2 rounded-full" />
                  {current.statusLabel}
                </p>
                <h3 className="mt-2 text-2xl">{current.nameAr}</h3>
                <p className="font-latin text-cream-200/80 text-sm tracking-widest uppercase">
                  {current.nameEn.replace(" ", "")} {current.typeLabel && ""}
                </p>
                <p className="text-gold-400 mt-2 text-xl">{current.typeLabel}</p>
                <p className="text-gold-400 text-xl">
                  {current.city} - {current.district}
                </p>
                <Link
                  href={`/projects/${current.slug}`}
                  className="mt-3 inline-block text-sm underline underline-offset-4"
                >
                  عرض المشروع
                </Link>
              </div>
            </div>
          </aside>
        ) : null}
      </div>
    </div>
  );
}
