"use client";

import * as React from "react";
import Image from "next/image";
import Link from "next/link";
import {
  ProjectHeroSpecs,
  ProjectHeroTitle,
  ProjectTabs,
  type HeroProject,
} from "@/components/projects/project-hero";
import { Pill } from "@/components/ui/badge";
import { COPY } from "@/lib/copy";
import { cn } from "@/lib/utils";

type Props = {
  taglineAr: string;
  taglineEn: string;
  brandImage: string;
  projects: HeroProject[];
};

const AUTO_MS = 7000;

/**
 * Home hero: slide 0 is the brand statement, then one slide per featured
 * project; the strip of project tabs switches slides. Auto-advance pauses on
 * hover, focus and when motion is reduced.
 */
export function HeroSlider({ taglineAr, taglineEn, brandImage, projects }: Props) {
  const [active, setActive] = React.useState<string | null>(null);
  const [paused, setPaused] = React.useState(false);
  const reduced = React.useRef(false);

  React.useEffect(() => {
    reduced.current = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  }, []);

  React.useEffect(() => {
    if (paused || reduced.current || projects.length === 0) return;
    const t = window.setInterval(() => {
      setActive((cur) => {
        const order = [null, ...projects.map((p) => p.slug)];
        const idx = order.indexOf(cur);
        return order[(idx + 1) % order.length] ?? null;
      });
    }, AUTO_MS);
    return () => window.clearInterval(t);
  }, [paused, projects]);

  const current = projects.find((p) => p.slug === active) ?? null;

  return (
    <section
      aria-roledescription="carousel"
      aria-label="أحدث مشاريع رُصافة"
      className="bg-navy-900 relative isolate flex min-h-[100svh] flex-col justify-end overflow-hidden"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      onFocusCapture={() => setPaused(true)}
      onBlurCapture={() => setPaused(false)}
    >
      {/* Backgrounds: all rendered, active one visible — crossfade without layout shift. */}
      <Image
        src={brandImage}
        alt=""
        fill
        priority
        sizes="100vw"
        className={cn(
          "object-cover transition-opacity duration-1000",
          current ? "opacity-0" : "opacity-100",
        )}
      />
      {projects.map((p) =>
        p.image ? (
          <Image
            key={p.slug}
            src={p.image}
            alt=""
            fill
            sizes="100vw"
            className={cn(
              "object-cover transition-opacity duration-1000",
              current?.slug === p.slug ? "opacity-100" : "opacity-0",
            )}
          />
        ) : null,
      )}
      <div aria-hidden="true" className="bg-navy-950/45 absolute inset-0" />
      <div
        aria-hidden="true"
        className="from-navy-950/85 via-navy-950/30 absolute inset-x-0 bottom-0 h-80 bg-gradient-to-t to-transparent"
      />

      <div
        className="container-site relative flex flex-1 flex-col justify-center pt-32 pb-8"
        aria-live="polite"
      >
        {current ? (
          <div
            id={`hero-slide-${current.slug}`}
            role="tabpanel"
            aria-labelledby={`hero-tab-${current.slug}`}
            className="animate-rise max-w-xl"
          >
            <ProjectHeroTitle project={current} />
            <ProjectHeroSpecs project={current} className="mt-12" />
            <Link
              href={`/projects/${current.slug}`}
              className="text-gold-400 mt-10 inline-block text-lg underline-offset-4 hover:underline"
            >
              تفاصيل المشروع ←
            </Link>
          </div>
        ) : (
          <div className="animate-rise mx-auto max-w-3xl text-center">
            <h1 className="font-display text-cream-100 text-6xl leading-[1.15] md:text-8xl">
              {taglineAr}
            </h1>
            <p className="font-latin text-gold-400 mt-2 text-2xl md:text-4xl">{taglineEn}</p>
            <Link
              href="/projects/latest"
              className="mt-14 inline-flex flex-col items-center gap-3 focus-visible:outline-offset-8"
            >
              <Pill className="text-xl">{COPY.home.latestProjects}</Pill>
              <span aria-hidden="true" className="flex gap-1.5">
                <span className="bg-cream-100/80 size-1.5 rounded-full" />
                <span className="bg-cream-100/80 size-1.5 rounded-full" />
                <span className="bg-cream-100/80 size-1.5 rounded-full" />
              </span>
            </Link>
          </div>
        )}
      </div>

      <div className="container-wide relative pb-10">
        <ProjectTabs
          projects={projects}
          activeSlug={active}
          onSelect={(slug) => setActive((cur) => (cur === slug ? null : slug))}
        />
      </div>
    </section>
  );
}
