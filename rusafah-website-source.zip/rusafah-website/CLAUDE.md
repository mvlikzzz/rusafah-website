# RUSAFAH public website — working rules for this repository

This repository is the **public marketing website** of RUSAFAH Real Estate. It is
governed by the RUSAFAH Platform specification: read the platform repository's
`CLAUDE.md`, `DECISIONS.md` and `ASSUMPTIONS.md` first (canonical copies live in
the platform repository; a copy of the spec also sits one directory up from the
design package). Every rule there applies here unless this file narrows it.

What is different about this codebase:

- **No authenticated users, no money, no participation records.** There is no
  investor data here and there must never be. Leads (contact requests, interest
  registrations, visit bookings, newsletter sign-ups) are the only personal data,
  and they are stored minimally — no IP addresses, no free-text beyond the message
  the visitor typed.
- **Content is data.** Projects, articles, partners, certificates, headline
  figures, contact facts and legal texts are rows (`db/schema`), seeded from the
  transcription of the approved artboards in `db/seed/content.ts`. Fixed page copy
  is in `lib/copy.ts`. Nothing else is hardcoded in components.
- **Design fidelity is a requirement.** The artboards in the design package are
  the reference; deviations are recorded in `ASSUMPTIONS.md` (AW- items).
- **Website-scoped registers.** `DECISIONS.md` (DW-/EW- items) and
  `ASSUMPTIONS.md` (AW- items) in this repository hold what is specific to the
  website. Anything that changes a money figure, a permission decision or a legal
  position still goes to the platform register as a `D-` item.
- **Every stage ends green:** `pnpm lint && pnpm typecheck && pnpm test &&
pnpm test:integration && pnpm test:e2e`. Quote real output in stage reports.
