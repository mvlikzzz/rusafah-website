# رُصافة العقارية — الموقع الإلكتروني العام

The public website of RUSAFAH Real Estate, built from the approved Illustrator
artboards (September 2026). Arabic, right-to-left, Next.js App Router, Postgres.

Governing spec: the RUSAFAH Platform `CLAUDE.md` (the platform repository is the
canonical copy). This repository's own `CLAUDE.md`, `DECISIONS.md` and
`ASSUMPTIONS.md` hold what is specific to the website.

## Run it locally

Requirements: Node 26 (see `.nvmrc`), pnpm 10+, Docker.

```bash
pnpm install
cp .env.example .env.local        # already contains working local values
pnpm setup                        # docker compose up, migrate, seed
pnpm dev                          # http://localhost:3000
```

Mail sent by the notification worker (new leads, newsletter sign-ups) lands in
Mailpit at http://localhost:8026.

## Scripts

| Script                                                                   | What it does                                                                                        |
| ------------------------------------------------------------------------ | --------------------------------------------------------------------------------------------------- |
| `pnpm dev` / `pnpm build` / `pnpm start`                                 | Next.js. `predev`/`prebuild` copy the MapLibre worker into `public/map`.                            |
| `pnpm lint`, `pnpm typecheck`, `pnpm format:check`, `pnpm check:logical` | Static gates (the last one forbids physical direction utilities — CLAUDE.md §5).                    |
| `pnpm db:generate`                                                       | Generate a migration from `db/schema`. Write its `.down.sql` by hand (E-09).                        |
| `pnpm db:migrate`, `pnpm db:rollback`, `pnpm db:reset`                   | Apply, revert one, or wipe and rebuild the dev database.                                            |
| `pnpm db:seed`                                                           | Idempotent content seed (`db/seed/content.ts`).                                                     |
| `pnpm test`                                                              | Unit tests (Vitest).                                                                                |
| `pnpm test:integration`                                                  | Prepares `TEST_DATABASE_URL` and runs DB-backed tests.                                              |
| `pnpm check:migrations`                                                  | up → down → up on the test database.                                                                |
| `pnpm test:e2e`                                                          | Playwright e2e + axe accessibility (builds and starts the app unless `PLAYWRIGHT_BASE_URL` is set). |
| `pnpm admin:create -- --email … --password … --name … [--role owner]`    | Create or reset a password for an `/admin` CMS user.                                                |

## Where things live

```
app/            routes: /, /projects, /projects/latest, /projects/[slug], /about,
                /blog, /blog/[slug], /contact, /privacy, /terms, /search, /admin
components/     UI kit (ui/), shell (header, footer, drawer), patterns, map, admin
modules/        projects, posts, site, leads, notifications, search, admin,
                media, integrations/crm — service functions only
db/             Drizzle schema, migrations (+ hand-written down files), seed
lib/            env, fonts, formatters, page copy, password hashing, sessions
public/images   photos exported from the design package; masks/ are colourable marks
public/map      self-hosted Riyadh vector tiles (PMTiles), glyphs, RTL plugin
public/uploads  images uploaded through the admin CMS (local disk — see EW-09)
tests/          unit, integration, e2e, a11y
docs/           ADRs and runbooks
```

## Editing content

Content is data, not code. Most of it — site settings, headline figures,
project pricing/units/status, and project images — is editable at `/admin`
without a deploy (`docs/runbooks/admin-cms.md`). What isn't yet (new projects,
blog bodies, legal documents) goes through `db/seed/content.ts` — see
`docs/runbooks/content-editing.md`.

## CMS and CRM integration

- **Admin CMS** (`/admin`): session-cookie auth, every mutation server-authorized
  and audited. `docs/runbooks/admin-cms.md`.
- **CRM**: leads can sync to any CRM reachable by a REST/PostgREST webhook
  (`CRM_PROVIDER=webhook`), through the same transactional outbox used for
  email alerts. Off by default (`CRM_PROVIDER=none`). `docs/runbooks/crm-integration.md`.

## Leads

Every public form (contact, register interest, book a visit, newsletter) writes to
Postgres inside one transaction together with a row in `notification_outbox`.
A pg-boss worker running inside the Next.js server delivers the alert by SMTP
(`SMTP_URL`, `LEADS_NOTIFY_EMAIL`). A failed email never loses the lead.
